function testRequireFunction(a, b) {
    console.log('进入testRequireFunction方法');
    console.log(a, b);
}
module.exports = testRequireFunction;